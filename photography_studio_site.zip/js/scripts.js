// Small scripts: set footer years
document.addEventListener('DOMContentLoaded', function(){
  var y = new Date().getFullYear();
  ['year','year2','year3','year4'].forEach(function(id){
    var el = document.getElementById(id);
    if(el) el.textContent = y;
  });
});
