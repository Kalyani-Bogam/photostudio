Aperture Studio - Photography website (static)
Files included:
- index.html
- gallery.html
- about.html
- contact.html
- css/styles.css
- js/scripts.js
- images/ (6 placeholder images recommended: photo1.jpg ... photo6.jpg)

How to use:
1. Replace images in /images with your real photos (recommended size: 1200x800).
2. Edit contact details and photographer name in the HTML files.
3. To publish on GitHub Pages:
   - Create a repo named: yourusername.github.io
   - Upload all files to the repo root
   - GitHub Pages will publish at: https://yourusername.github.io
4. Or deploy on Netlify by dragging the site folder to Netlify 'Deploy' area.

Need me to:
- Customize text/logo with your studio name and contact details
- Add real photos into the gallery if you upload them here
- Deploy directly to your GitHub (you can share repo access)